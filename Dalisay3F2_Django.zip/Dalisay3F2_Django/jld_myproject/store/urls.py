from django.urls import path
from . import views

urlpatterns = [
    path('',views.home, name='store_index'),
    path('products/',views.products, name='store_products'),
    path('checkout/',views.checkout, name='store_checkout'),
]